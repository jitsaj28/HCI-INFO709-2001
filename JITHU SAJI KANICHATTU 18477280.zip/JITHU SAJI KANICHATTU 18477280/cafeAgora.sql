-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 14, 2020 at 10:51 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cafeAgora`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `date` varchar(255) NOT NULL,
  `time` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `table` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

CREATE TABLE `carts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `pid` int(11) NOT NULL,
  `userid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `carts`
--

INSERT INTO `carts` (`id`, `created_at`, `updated_at`, `pid`, `userid`) VALUES
(14, '2020-06-06 14:16:54', '2020-06-06 14:16:54', 5, 2);

-- --------------------------------------------------------

--
-- Table structure for table `catogories`
--

CREATE TABLE `catogories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `catogories`
--

INSERT INTO `catogories` (`id`, `created_at`, `updated_at`, `name`) VALUES
(1, NULL, NULL, 'Bakes'),
(2, NULL, NULL, 'Vegetarian'),
(3, NULL, NULL, 'Non-Vegetarian');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2019_08_19_000000_create_failed_jobs_table', 1),
(3, '2020_04_19_022153_create_catogories_table', 1),
(4, '2020_04_19_055159_add_address_to_users', 1),
(5, '2020_04_19_060051_add_phoneno_to_users', 1),
(6, '2020_04_19_060335_create_carts_table', 1),
(7, '2020_04_19_060651_create_products_table', 1),
(8, '2020_05_10_081932_create_shoppingcart', 1);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` bigint(20) NOT NULL,
  `quantity` bigint(20) NOT NULL,
  `categoryid` int(11) NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `created_at`, `updated_at`, `name`, `price`, `quantity`, `categoryid`, `image`) VALUES
(1, NULL, NULL, 'SWISS BIRCHER MUESLI', 15, 0, 2, 'swiss_bircher_muesli.jpeg'),
(2, NULL, NULL, 'VIETNAMESE PORK BELLY SALAD', 20, 0, 3, 'pork_belly.jpg'),
(3, NULL, NULL, 'SPANISH THREE EGG OMELETTE', 17, 0, 3, 'spanish_omlette.jpg'),
(4, NULL, NULL, 'SEASONAL SWEET MUFFINS', 3, 0, 1, 'seasonal_sweet_muffin.jpeg'),
(5, NULL, NULL, 'CINNAMON SCROLLS', 5, 0, 1, 'cinnamon_scroll.jpg'),
(6, NULL, NULL, 'HUEVOS RANCHEROS (COWBOY EGGS)', 20, 0, 3, 'HUEVOS RANCHEROS (COWBOY EGGS).jpg'),
(7, NULL, NULL, 'HUEVOS RANCHEROS (COWBOY TOFU)', 20, 0, 2, 'HUEVOS RANCHEROS (COWBOY TOFU).jpeg'),
(8, NULL, NULL, 'AGORA EGGS BENNY(FREE RANGE BACON)', 22, 0, 3, 'AGORA EGGS BENNY(FREE RANGE BACON).jpg'),
(9, NULL, NULL, 'AGORA EGGS BENNY(HOUSE SMOKED SALMON)', 22, 0, 3, 'AGORA EGGS BENNY(FREE RANGE SALMON).jpg'),
(10, NULL, NULL, 'AGORA EGGS BENNY(ROASTED PORTABELLO)', 22, 0, 2, 'AGORA EGGS BENNY(FREE RANGE PORTABELLO).jpg'),
(11, NULL, NULL, 'CARIBBEAN TACOS(FRIED CHICKEN)', 18, 0, 3, 'CARIBBEAN TACOS(FRIED CHICKEN).jpg'),
(12, NULL, NULL, 'CARIBBEAN TACOS(CAULIFLOWER)', 18, 0, 2, 'CARIBBEAN TACOS(FRIED CAULIFLOWER).jpg'),
(13, NULL, NULL, 'KOREAN STICKY WINGS', 18, 0, 3, 'KOREAN STICKY WINGS.jpg'),
(14, NULL, NULL, 'KOREAN STICKY WINGS(CAULIFLOWER)', 18, 0, 2, 'KOREAN STICKY WINGS(CAULIFLOWER).jpg'),
(15, NULL, NULL, 'BUFFALO WINGS', 16, 0, 3, 'BAFFALO.jpg'),
(16, NULL, NULL, 'BABY BENNY(BACON)', 13, 0, 3, 'BABY BENNY(BACON).jpg'),
(17, NULL, NULL, 'BABY BENNY(MUSHROOM)', 13, 0, 2, 'BABY BENNY(MUSHROOM).jpg');

-- --------------------------------------------------------

--
-- Table structure for table `shopping`
--

CREATE TABLE `shopping` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `pid` int(11) NOT NULL,
  `userid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phoneno` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `address`, `phoneno`) VALUES
(1, 'Sue', 'sue@123.com', NULL, '$2y$10$hsnVhXwW.NUJVKQ6I55rluYY4d.0LtLLK7J/C.MqtU.br0tX3Z8Ba', NULL, '2020-05-26 12:30:25', '2020-05-26 12:30:25', '8/11A ruakwii road', 939892498393),
(2, 'user123', 'user@123.com', NULL, '$2y$10$i0Aje6pnrxMsmrreC9ZLrejFoKK9YqazUXSxFUIWec/fMATXjhtTq', NULL, '2020-05-26 14:43:50', '2020-05-26 14:43:50', 'agdvgdj123', 483720421);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `catogories`
--
ALTER TABLE `catogories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shopping`
--
ALTER TABLE `shopping`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `carts`
--
ALTER TABLE `carts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `catogories`
--
ALTER TABLE `catogories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `shopping`
--
ALTER TABLE `shopping`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
