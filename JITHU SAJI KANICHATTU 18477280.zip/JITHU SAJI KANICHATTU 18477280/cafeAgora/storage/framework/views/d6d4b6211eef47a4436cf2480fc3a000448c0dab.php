

<?php $__env->startSection('content'); ?>
<div class="container" style="width: 50%">
  <h2>Register</h2>
<form action="<?php echo e(url('post-registration')); ?>" method="POST" id="regForm">
    <?php echo e(csrf_field()); ?>

   <div class="form-label-group">
    <label for="inputName">Name</label>

     <input type="text" id="inputName" name="name" class="form-control" placeholder="Full name" autofocus>
     <?php if($errors->has('name')): ?>
     <span class="error"><?php echo e($errors->first('name')); ?></span>
     <?php endif; ?>       

   </div> 
   <div class="form-label-group">
    <label for="inputEmail">Email address</label>
     <input type="email" name="email" id="inputEmail" class="form-control" placeholder="Email address">
     <?php if($errors->has('email')): ?>
     <span class="error"><?php echo e($errors->first('email')); ?></span>
     <?php endif; ?>    
   </div> 

   <div class="form-group">
    <label for="inputAddress">Address</label>
    <input type="text" id="inputAddress" name="address" class="form-control" placeholder="Full address" autofocus>
    <?php if($errors->has('address')): ?>
    <span class="error"><?php echo e($errors->first('address')); ?></span>
    <?php endif; ?>       

  </div>

  <div class="form-group">
    <label for="inputPhoneno">Phone No</label>
    <input type="text" id="inputPhoneno" name="phoneno" class="form-control" placeholder="Phone No" autofocus>

    <?php if($errors->has('phoneno')): ?>
    <span class="error"><?php echo e($errors->first('phoneno')); ?></span>
    <?php endif; ?>       

  </div>

   <div class="form-label-group">
    <label for="inputPassword">Password</label>
     <input type="password" name="password" id="inputPassword" class="form-control" placeholder="Password">
     <?php if($errors->has('password')): ?>
     <span class="error"><?php echo e($errors->first('password')); ?></span>
     <?php endif; ?>  
   </div>

   <button class="btn btn-lg btn-primary btn-block btn-login text-uppercase font-weight-bold mb-2" type="submit">Sign Up</button>
   <div class="text-center">If you have an account?
     <a class="small" href="<?php echo e(url('login')); ?>">Sign In</a></div>
 </form>
</div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\foodorder\resources\views/registration.blade.php ENDPATH**/ ?>