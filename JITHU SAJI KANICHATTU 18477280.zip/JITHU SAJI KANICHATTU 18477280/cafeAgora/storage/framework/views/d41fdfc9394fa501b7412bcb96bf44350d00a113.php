

<?php $__env->startSection('content'); ?>
<?php if(Auth::check()): ?>
<div class='useridhidden hidden'><?php echo e(Auth::user()->id); ?></div>
<?php endif; ?>





<style>
.price{
  color:005B8F;
  text-align:center;
}
.btn{

  background-color: 005B8F;
  color: white;  
  text-align: 125px;
  text-decoration: none;
  display: inline-block;
}

.btn:hover, a:active {
  background-color: red;
}

caption { 
  display: table-caption;
  text-align: center;
  color:005B8F;
  background-color:B5651D;
}


</style>




<div class='col-md-9'>
  
  <div class="row" >
    <h3>Non-Vegetarian<h3>
      <?php if(count($data['items2'])>0): ?>
          <?php $__currentLoopData = $data['items2']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-sm-4">
              <div class="panel panel-primary">
              <div class="panel-heading"><?php echo e($item->name); ?></div>
                <div class="panel-body"><img src="images/<?php echo e($item->image); ?>" class="img-responsive" style="width:100%" alt="Image"></div>
                <div class="price"><?php echo e($item->price); ?> $</div>
              <a href="#" class="btn">Add to Cart
                <div class="hidden"><?php echo e($item->id); ?></div>
              </a>
              </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php else: ?>
      <?php endif; ?>
      
    </div>
</div>



<!--  Cart -->

<?php if(Auth::check()): ?>
<div>
  <table class="table table-hover" style="width: 20%">
  <Caption>Shopping Cart</Caption>
      <thead>
        <tr>
          <th>Name</th>
          <th>Price</th>
          <th width="1px"></th>
          
        </tr>
      </thead>
      <tbody id="tbody">

      </tbody>
      <tfoot id="tfoot">
          
      </tfoot>
  </table>
</div>
<?php endif; ?>
  <?php $__env->stopSection(); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script>
    $(document).ready(function(){
      $userid = $('.container').find('.useridhidden').html();

      //onload
        $sum=0;
        // event.preventDefault();
        $.ajax({
            url:"<?php echo e(url('showcart')); ?>"+"/"+$userid,
            method: "GET",
            // data: {selectedCountry },
            contentType: false,
            dataType: "json",
            success:function(data){
              debugger;
                $('#tbody').html('');
                $('#tfoot').html('');
                data.forEach(element => {
                    $sum = $sum + element.price;
                    $('#tbody').append("<tr id='"+element.id+"'"+'><td>'+element.name+'</td><td>'+element.price+"</td><td></td><td><a href='#' id='"+element.id+"' class='remove btn btn-danger'>Remove</a></td></tr>'");
                });
                
                $('#tfoot').append('<tr><td>Total</td><td>'+$sum+'</td><td></td></tr>');
            },
            error: function(xhr, textStatus, error){
                console.log(xhr.statusText);
                console.log(textStatus);
                console.log(error);
            }

        })
      //onadd
        $(".btn").click(function(){
            $sum=0;
            var selectedDate = $(this).find('.hidden').html();
            event.preventDefault();
            $.ajax({
                url:"<?php echo e(url('addcart')); ?>"+"/"+selectedDate+"/"+$userid,
                method: "GET",
                // data: {selectedCountry },
                contentType: false,
                dataType: "json",
                success:function(data){
                  
                    // alert(data.price);
                    $('#tbody').html('');
                    $('#tfoot').html('');
                    data.forEach(element => {
                        $sum = $sum + element.price;
                        $('#tbody').append("<tr id='"+element.id+"'"+'><td>'+element.name+'</td><td>'+element.price+"</td><td></td><td><a href='#' id='"+element.id+"' class='remove btn btn-danger'>Remove</a></td></tr>'");
                    });
                    
                    $('#tfoot').append('<tr><td>Total</td><td>'+$sum+'</td><td></td></tr>');
                },
                error: function(xhr, textStatus, error){
                    console.log(xhr.statusText);
                    console.log(textStatus);
                    console.log(error);
                }

            })
        });

      //onremove
      $('#tbody').on('click', '.remove', function () {
          $id = $(this).attr('id');
          $sum=0;
          event.preventDefault();
            $.ajax({
                url:"<?php echo e(url('deletecart')); ?>"+"/"+$id+"/"+$userid,
                method: "GET",
                // data: {selectedCountry },
                contentType: false,
                dataType: "json",
                success:function(data){
                  debugger;
                    // alert(data);
                    // alert(data.price);
                    $('#tbody').html('');
                    $('#tfoot').html('');
                    data.forEach(element => {
                        $sum = $sum + element.price;
                        $('#tbody').append("<tr id='"+element.id+"'"+'><td>'+element.name+'</td><td>'+element.price+"</td><td></td><td><a href='#' id='"+element.id+"' class='remove btn btn-danger'>Remove</a></td></tr>'");
                    });
                    
                    $('#tfoot').append('<tr><td>Total</td><td>'+$sum+'</td><td></td></tr>');
                },
                error: function(xhr, textStatus, error){
                    console.log(xhr.statusText);
                    console.log(textStatus);
                    console.log(error);
                }

            })
        });
    });
    </script>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/cafeAgora/resources/views/pages/nonvegetarian.blade.php ENDPATH**/ ?>