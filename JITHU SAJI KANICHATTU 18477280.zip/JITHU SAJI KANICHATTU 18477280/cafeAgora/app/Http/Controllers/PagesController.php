<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;
use App\Cart;
use App\Category;
Use App\Booking;
use DB;

class PagesController extends Controller
{
    //Homepage Menu view
    public function index(){
         //$data = Product::all();
        $items = Product::where('categoryid','=',1)->get();//bakes
        $items1 = Product::where('categoryid','=',2)->get();//veg
        $items2 = Product::where('categoryid','=',3)->get();//non-veg
        $data = array(
            'items'=>$items,//bakes
            'items1'=>$items1,//veg
            'items2'=>$items2//nonveg
        );
        
        return view('pages.index', ['data' => $data]);
        
    }
//Bakes View
    public function bakes(){
        $items= Product::where('categoryid','=',1)->get();
         $data = array('items'=>$items);
        return view('pages.bakery', ['data' => $data]);
    }

//Vegetable view
    public function veg(){
        $items1 = Product::where('categoryid','=',2)->get();        
        $data = array('items1'=>$items1);        
        return view('pages.vegetarian', ['data' => $data]);
    }



//Non-Veg view
    public function nonveg(){
        $items2 = Product::where('categoryid','=',3)->get();
         $data = array('items2'=>$items2);
        return view('pages.nonvegetarian', ['data' => $data]);
    }


    public function postBooking()
    {  

 
        $check = $this->create();
       
        
        return Redirect::to("bookingg")->withSuccess('Great! You have Successfully loggedin');
    }

    public function create()
    {
      return Booking::create([
        'date' => ['date'],
        // 'time' => $data['time'],
        // 'name' => $data['name'],
        // 'email' => $data['email'],
        // 'mobile' => $data['mobile'],
        // 'address' => $data['address'],
        // 'table' => $data['table']

      ]);
     
    }





public function bookingg(){
            
    // $booking = new Booking();
    // //$cart->pid = $id;
    // //$cart->userid = $userid;
    // $book->save();
    
    
    // $carts = Booking::select('carts.id' ,'carts.pid', 'carts.created_at',
    // 'products.name', 'users.name as uname', 'products.price')
    // ->join('products', 'products.id', '=', 'carts.pid')
    // ->join('users', 'users.id', '=', 'carts.userid')
    // ->where('userid', '=', $userid)
    // ->get();
    // return $book;
     return view('bookingg');
    

}


//all menu products
    public function products(){
        // $items = DB::table('items')->where('categoryid','1')->get();
        return view('products');
    }

    public function addCart($id, $userid){
            
            $cart = new Cart();
            $cart->pid = $id;
            $cart->userid = $userid;
            $cart->save();
            
            
            $carts = Cart::select('carts.id' ,'carts.pid', 'carts.created_at',
            'products.name', 'users.name as uname', 'products.price')
            ->join('products', 'products.id', '=', 'carts.pid')
            ->join('users', 'users.id', '=', 'carts.userid')
            ->where('userid', '=', $userid)
            ->get();
            return $carts;
            // return Redirect::to('showcart/'.$userid);
            

    }

    public function showCart($userid){
        $carts = Cart::select('carts.id' ,'carts.pid', 'carts.created_at',
        'products.name', 'users.name as uname', 'products.price')
        ->join('products', 'products.id', '=', 'carts.pid')
        ->join('users', 'users.id', '=', 'carts.userid')
        ->where('userid', '=', $userid)
        ->get();
        return $carts;  
    }

    public function deletecart($id,$userid) {
        Cart::where('id', '=', $id)->delete();
        $data=$this->showcart($userid);
        return $data;
    }


    public function shopping(){

        $s = new Shopping();
        $s->pid = $id;
        $s->userid = $userid;
        $s->save();
        
        
        $s = Shopping::select('shopping.id' ,'shopping.pid', 'shopping.created_at',
        'products.name', 'users.name as uname', 'products.price')
        ->join('products', 'products.id', '=', 'carts.pid')
        ->join('users', 'users.id', '=', 'carts.userid')
        ->where('userid', '=', $userid)
        ->get();
        return $s;
    }
    
}
