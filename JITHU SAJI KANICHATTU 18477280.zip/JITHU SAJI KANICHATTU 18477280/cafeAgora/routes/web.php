<?php

use Illuminate\Support\Facades\Route;
use App\User;
use App\Mail\WelcomeMail;  
//use Illuminate\Support\Facades\Mail;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/','PagesController@index');
Route::get('vegetarian','PagesController@veg');
Route::get('nonvegetarian','PagesController@nonveg');
Route::get('bakery','PagesController@bakes');


/*
Route::get('/mail', function () {
  Mail::to('email@email.com')->send(new WelcomeMail());
  return new WelcomeMail();
 });
*/
Route::get('addcart/{id}/{userid}', 'PagesController@addCart');
Route::get('showcart/{userid}', 'PagesController@showCart');
Route::get('deletecart/{id}/{userid}', 'PagesController@deletecart');

Route::get('shopping/{id}/{userid}', 'PagesController@shopping');
// Route::get('/products','PagesController@products');

//login n registration
Route::get('login', 'AuthController@index');
  Route::post('post-login', 'AuthController@postLogin'); 
  Route::get('registration', 'AuthController@registration');
  Route::post('post-registration', 'AuthController@postRegistration'); 
  Route::get('dashboard', 'AuthController@dashboard'); 
  Route::get('logout', 'AuthController@logout');


  //Booking
  Route::get('booking', function () {
    return view('booking');});

Route::get('bookingg', function () {
return view('bookingg');});
  // Route::get('booking',);
  //  Route::get('bookingg','PagesController@bookingg');
  //  Route::get('post-booking','PagesController@bookingg');

//Route::get('mail','function' (){

  //User::find(1)->notify(new TaskCompleted);
  //return view('/');
//});