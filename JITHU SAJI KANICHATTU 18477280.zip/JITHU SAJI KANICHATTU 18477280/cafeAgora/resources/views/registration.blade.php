@extends('layout')

@section('content')
<div class="container" style="width: 50%">
  <h2>Register</h2>
<form action="{{url('post-registration')}}" method="POST" id="regForm">
    {{ csrf_field() }}
   <div class="form-label-group">
    <label for="inputName">Name</label>

     <input type="text" id="inputName" name="name" class="form-control" placeholder="Full name" autofocus>
     @if ($errors->has('name'))
     <span class="error">{{ $errors->first('name') }}</span>
     @endif       

   </div> 
   <div class="form-label-group">
    <label for="inputEmail">Email address</label>
     <input type="email" name="email" id="inputEmail" class="form-control" placeholder="Email address">
     @if ($errors->has('email'))
     <span class="error">{{ $errors->first('email') }}</span>
     @endif    
   </div> 

   <div class="form-group">
    <label for="inputAddress">Address</label>
    <input type="text" id="inputAddress" name="address" class="form-control" placeholder="Full address" autofocus>
    @if ($errors->has('address'))
    <span class="error">{{ $errors->first('address') }}</span>
    @endif       

  </div>

  <div class="form-group">
    <label for="inputPhoneno">Phone No</label>
    <input type="text" id="inputPhoneno" name="phoneno" class="form-control" placeholder="Phone No" autofocus>

    @if ($errors->has('phoneno'))
    <span class="error">{{ $errors->first('phoneno') }}</span>
    @endif       

  </div>

   <div class="form-label-group">
    <label for="inputPassword">Password</label>
     <input type="password" name="password" id="inputPassword" class="form-control" placeholder="Password">
     @if ($errors->has('password'))
     <span class="error">{{ $errors->first('password') }}</span>
     @endif  
   </div>

   <button class="btn btn-lg btn-primary btn-block btn-login text-uppercase font-weight-bold mb-2" type="submit">Sign Up</button>
   <div class="text-center">If you have an account?
     <a class="small" href="{{url('login')}}">Sign In</a></div>
 </form>
</div>
 @endsection