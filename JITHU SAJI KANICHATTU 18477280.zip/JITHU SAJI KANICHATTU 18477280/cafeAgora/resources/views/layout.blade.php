<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
    /* Remove the navbar's default rounded borders and increase the bottom margin */ 
    .bg-color
    {
      
    }
    .navbar {
      margin-bottom: 0px;
      border-radius: 0;

    
    }
    
    /* Remove the jumbotron's default bottom margin */ 
     .jumbotron {
      margin-bottom: 0;

    }
    .JumboHeaderImg{
      background-image: url("{{ asset('images/image1.jpeg') }}");
      background-size: cover;
      background-repeat: no-repeat;
      color:white;
      height: 300px;
    }

    .container {
    background-image: url("{{ asset('images/back1.jpg') }}");
    background-size: cover;
      background-repeat: no-repeat;
      color:white;
      min-height: auto;
    max-height: auto;
    
    /*border: 2px dashed #333;*/
}

body  {
  background-image: url("{{ asset('images/back.jpg') }}");
  background-color: #cccccc;
}


.table{
  background-color:white;
  ;
}

    
   
    /* Add a gray background color and some padding to the footer */
    footer {
      background-color: #f2f2f2;
      padding: 25px;
    }

    .w3-myfont {
  font-family: "Comic Sans MS", cursive, sans-serif;
}

  </style>
</head>
<body>

<!-- <div class="jumbotron JumboHeaderImg">

 <a><img src="{{asset('images/image1.jpeg')}}" style="width:100%;height:200;"> 

  <div class="container text-center" image src="image1.jpeg" >
    <h1>Delights TakeAway</h1>      
    <p>Mission, Vission & Values</p>
  </div>
</div> -->




<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="{{ asset('logo.png') }}"></a>
      <a class="navbar-brand" href="logo.png"></a>
      
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">

        <li class="active"><a href="/cafeAgora/public/">Home</a></li>
       {{-- <li><a href="/products">Our Menu</a></li>--}}
        
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">Our Menu
          <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="vegetarian">Vegetarian</a></li>
            <li><a href="nonvegetarian">Non-vegetarian</a></li>
            <li><a href="bakery">Fresh Bakes</a></li>
          </ul>
      </li>
        <li><a href="booking">Book a Table</a></li>
        <!--<li><a href="#">About Us</a></li>
        <li><a href="#">Contact Us</a></li>-->
      </ul>
      <ul class="nav navbar-nav navbar-right">
        @if(Auth::check())
        
          
          <li><a href=""><span class="glyphicon glyphicon-user"></span>{{ Auth::user()->name }}</a></li>
         <!-- <li><a href="/showcart"><span class="glyphicon glyphicon-shopping-cart"></span> Cart</a></li>-->
        <li><a href="{{url('logout')}}"><span class="glyphicon glyphicon-user"></span>Logout</a></li>
        @else
        <li><a href="{{url('login')}}"><span class="glyphicon glyphicon-user"></span>Login</a></li>
        <li><a href="{{url('registration')}}"><span class="glyphicon glyphicon-user"></span>Register</a></li>
        
        @endif

      </ul>
    </div>
  </div>
</nav>

<div class="jumbotron JumboHeaderImg d-none d-lg-block d-xl-block">
  <div class="container1 text-center">
    <h1 class="w3-myfont">Cafe Agora</h1>      
    <p class="w3-myfont">You are our first priority</p>
  </div>
</div>

<div class="container">   
@yield('content') 
  
</div>

{{-- <footer class="container-fluid text-center">
  <p>Online Store Copyright</p>  
  <form class="form-inline">Get deals:
    <input type="email" class="form-control" size="50" placeholder="Email Address">
    <button type="button" class="btn btn-danger">Sign Up</button>
  </form>
</footer> --}}

</body>
</html>