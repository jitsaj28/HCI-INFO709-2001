@extends('layout')

@section('content')
@if(Auth::check())
<div class='useridhidden hidden'>{{Auth::user()->id}}</div>
@endif


<style>
.price{
  color:005B8F;
  text-align:center;
}
.btn{

  background-color: 005B8F;
  color: white;  
  text-align: 125px;
  text-decoration: none;
  display: inline-block;
  style="display: none"
}


.btn1{

background-color: 005B8F;
color: white;  
text-align: 125px;
text-decoration: none;
display: inline-block;
style="display: none"
}
.btn:hover, a:active {
  background-color: red;
}

caption { 
  display: table-caption;
  text-align: center;
  color:005B8F;
  background-color:B5651D;
}






</style>



<div class='col-md-8'>
<div class="row" >
  <h3 > <?php

{
  ?>
  <style>

  </style>
  <?php


}
?>Fresh Bakes<h3>

    @if(count($data['items'])>0)
        @foreach($data['items'] as $item)
        <div class="col-sm-5">
            <div class="panel panel-primary">
            <div class="panel-heading">{{$item->name}}</div>
              <div class="panel-body"><img src="images/{{$item->image}}" class="img-responsive"  alt="Image"></div>
            <div class="price" >{{$item->price}} $</div>
            <a href="#" class="btn" >Add to Cart
              <div class="hidden">{{$item->id}}</div>
            </a>
            </div>
          </div>
        @endforeach
    @else
  
    @endif
    
  </div>
  <br>

<div class="row" >
  <h3 >Vegetarian<h3>
    @if(count($data['items1'])>0)
        @foreach($data['items1'] as $item)
        <div class="col-sm-5">
            <div class="panel panel-primary">
            <div class="panel-heading">{{$item->name}}</div>
              <div class="panel-body"><img src="images/{{$item->image}}" class="img-responsive"  alt="Image"></div>
              <div class="price" >{{$item->price}} $</div>
            <a href="#" class="btn">Add to Cart
              <div class="hidden">{{$item->id}}</div>
            </a>
            </div>
          </div>
        @endforeach
    @else
    @endif
    
  </div>
  <br>
  
  <div class="row" >
    <h3>Non-Vegetarian<h3>
      @if(count($data['items2'])>0)
          @foreach($data['items2'] as $item)
          <div class="col-sm-5">
              <div class="panel panel-primary">
              <div class="panel-heading">{{$item->name}}</div>
                <div class="panel-body"><img src="images/{{$item->image}}" class="img-responsive" alt="Image"></div>
                <div class="price">{{$item->price}} $</div>
              <a href="#" class="btn">Add to Cart
                <div class="hidden">{{$item->id}}</div>
              </a>
              </div>
            </div>
          @endforeach
      @else
      @endif
      
    </div>
</div>





@if(Auth::check())
<div>
  <table class="table table-hover" style="width: 10%">
  <caption >Shopping Cart</caption>
      <thead>
        <tr>
          <th>Name</th>
          <th>Price</th>
          <th width="1px"></th>
          
        </tr>
      </thead>
      <tbody id="tbody">

      </tbody>
      <tfoot id="tfoot">
          
      </tfoot>
  </table>
</div>
@endif
  @endsection

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script>
    $(document).ready(function(){
      $userid = $('.container').find('.useridhidden').html();

      //onload
        $sum=0;
        // event.preventDefault();
        $.ajax({
            url:"{{ url('showcart') }}"+"/"+$userid,
            method: "GET",
            // data: {selectedCountry },
            contentType: false,
            dataType: "json",
            success:function(data){
              debugger;
                $('#tbody').html('');
                $('#tfoot').html('');
                data.forEach(element => {
                    $sum = $sum + element.price;
                    $('#tbody').append("<tr id='"+element.id+"'"+'><td>'+element.name+'</td><td>'+element.price+"</td><td></td><td><a href='#' id='"+element.id+"' class='remove btn btn-danger'>Remove</a></td></tr>'");
                });
                
                //$('#tfoot').append('<tr><td>Total</td><td>'+$sum+'</td><td></td></tr>');
                $('#tfoot').append('<tr><td>Total</td><td>'+$sum+'</td><td></td></tr><tr><td></td><td align="right"><a href="" class="btn2">Checkout</a></td></tr>' );
            },
            error: function(xhr, textStatus, error){
                console.log(xhr.statusText);
                console.log(textStatus);
                console.log(error);
            }

        })


       
          
        //-----
      //onadd
        $(".btn").click(function(){
            $sum=0;
            var selectedDate = $(this).find('.hidden').html();
            event.preventDefault();
            $.ajax({
                url:"{{ url('addcart') }}"+"/"+selectedDate+"/"+$userid,
                method: "GET",
                // data: {selectedCountry },
                contentType: false,
                dataType: "json",
                success:function(data){
                  
                    // alert(data.price);
                    $('#tbody').html('');
                    $('#tfoot').html('');
                    data.forEach(element => {
                        $sum = $sum + element.price;
                        $('#tbody').append("<tr id='"+element.id+"'"+'><td>'+element.name+'</td><td>'+element.price+"</td><td></td><td><a href='#' id='"+element.id+"' class='remove btn btn-danger'>Remove</a></td></tr>'");
                    });
                    
                    $('#tfoot').append('<tr><td>Total</td><td>'+$sum+'</td><td></td></tr><tr><td></td><td align="right"><a href="" class="btn2">Checkout</a></td></tr>' );
                    
                },
                error: function(xhr, textStatus, error){
                    console.log(xhr.statusText);
                    console.log(textStatus);
                    console.log(error);
                }

            })
        });

      //onremove
      $('#tbody').on('click', '.remove', function () {
          $id = $(this).attr('id');
          $sum=0;
          event.preventDefault();
            $.ajax({
                url:"{{ url('deletecart') }}"+"/"+$id+"/"+$userid,
                method: "GET",
                // data: {selectedCountry },
                contentType: false,
                dataType: "json",
                success:function(data){
                  debugger;
                    // alert(data);
                    // alert(data.price);
                    $('#tbody').html('');
                    $('#tfoot').html('');
                    data.forEach(element => {
                        $sum = $sum + element.price;
                        $('#tbody').append("<tr id='"+element.id+"'"+'><td>'+element.name+'</td><td>'+element.price+"</td><td></td><td><a href='#' id='"+element.id+"' class='remove btn btn-danger'>Remove</a></td></tr>'");
                    });
                    
                    $('#tfoot').append('<tr><td>Total</td><td>'+$sum+'</td><td></td></tr>');
                },
                error: function(xhr, textStatus, error){
                    console.log(xhr.statusText);
                    console.log(textStatus);
                    console.log(error);
                }

            })
        });

        $(".btn1").click(function(){
            $sum=0;
            var selectedDate = $(this).find('.hidden').html();
            event.preventDefault();
            $.ajax({
                url:"{{ url('addcart') }}"+"/"+selectedDate+"/"+$userid,
                method: "GET",
                // data: {selectedCountry },
                contentType: false,
                dataType: "json",
                success:function(data){
                  
                    // alert(data.price);
                    $('#tbody').html('');
                    $('#tfoot').html('');
                    data.forEach(element => {
                        $sum = $sum + element.price;
                        $('#tbody').append("<tr id='"+element.id+"'"+'><td>'+element.name+'</td><td>'+element.price+"</td><td></td><td><a href='#' id='"+element.id+"' class='remove btn btn-danger'>Remove</a></td></tr>'");
                    });
                    
                    $('#tfoot').append('<tr><td>Total</td><td>'+$sum+'</td><td></td></tr><tr><td></td><td align="right"><a href="">Checkout</a></td></tr>' );
                    
                },
                error: function(xhr, textStatus, error){
                    console.log(xhr.statusText);
                    console.log(textStatus);
                    console.log(error);
                }

            })
        });
    });

    
    </script>