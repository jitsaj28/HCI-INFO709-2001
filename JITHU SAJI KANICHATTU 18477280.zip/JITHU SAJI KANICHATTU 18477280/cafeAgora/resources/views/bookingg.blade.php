page2
@extends('layout')

@section('content')


<style>
table {
  border-collapse: collapse;
  text-align:center;
  
  
} 
table.d {
  table-layout: fixed;
  width: 100%; 
  height:80%; 
  color:white;
  text-align:center;
}

.circle{
  background-color:#8b4513;
  display:block;
  height:150px;
  width:150px;
  border-radius:80%;
  border:5px solid #ffff;
  margin:auto;
  color:#fff;
  line-height:140px;
  text-align:center
  
}

.rectangle{
    background-color:#8b4513;
  display:block;
  height:150px;
  width:150px;
  
  border:5px solid #ffff;
  margin:auto;
  color:#fff;
  line-height:140px;
  text-align:center 
}
input[type=radio] {
    margin: 1em 1em 1em 0;
    transform: scale(4, 4);
    -moz-transform: scale(4, 4);
    -ms-transform: scale(4, 4);
    -webkit-transform: scale(4, 4);
    -o-transform: scale(4, 4);
}

</style>
<form action="{{url('/')}}" method="GET" id="bookForm">

<h2>Select a Table</h2>
<table class="d">
  <tr>
    <th><span class ="rectangle"><input type="radio" id="S1" name="radio" value="Squaare1">Square1</div></th>
    <th><span class="circle"><input type="radio" id="C1" name="radio" value="Round1">Round1</th>
    <th><span class ="rectangle"><input type="radio" id="S2" name="time" value="Square2">Square2</th>
  </tr>
 
  <tr>
    <th><span class ="rectangle"><input type="radio" id="S3" name="radio" value="Square3">Square3</div></th>
    <th><span class="circle"><input type="radio" id="C2" name="radio" value="Round2">Round2</th>
    <th><span class ="rectangle"><input type="radio" id="S4" name="radio" value="Square4">Square4</th>
  </tr>

  <tr>
    <th><span class ="rectangle"><input type="radio" id="S5" name="radio" value="Square5">Square5</div></th>
    <th><span class="circle"><input type="radio" id="C3" name="radio" value="Round3">Round3</th>
    <th><span class ="rectangle"><input type="radio" id="S6" name="radio" value="Square6">Square6</th>
  </tr>
  
  
</table>
<button class="btn btn-lg btn-primary btn-block btn-login text-uppercase font-weight-bold mb-2" type="submit">Complete Booking</button>
</form>
 @endsection