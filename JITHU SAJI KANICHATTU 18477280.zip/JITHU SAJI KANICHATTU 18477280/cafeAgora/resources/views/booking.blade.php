@extends('layout')

@section('content')



<div class="container" style="width: 50%">
  <h2>Booking</h2>
  <a class="small" href="{{url('bookingg')}}">2</a></div>
<form action="{{url('bookingg')}}" method="GET" id="bookForm">
    {{ csrf_field() }}

   <div class="form-label-group">
    <label for="inputName">Date</label>

     <input type="date" id="select date" name="name" class="form-control" placeholder="Date" autofocus>
   
   </div> 


   <div class="form-label-group">
    <label for="inputName">Time</label>

<input type="radio" id="Morning" name="time" value="Morning">
  <label for="male">Morning</label>

  <input type="radio" id="Noon" name="time" value="Noon">
  <label for="female">Noon</label>

  <input type="radio" id="Evening" name="time" value="Evening">
  <label for="other">Evening</label>
   </div> 

   


   <div class="form-label-group">
    <label for="inputName">Name</label>

     <input type="text" id="inputName" name="name" class="form-control" placeholder="Full name" autofocus>
     @if ($errors->has('name'))
     <span class="error">{{ $errors->first('name') }}</span>
     @endif    

   </div> 

   <div class="form-group">
    <label for="inputAddress">Email</label>
    <input type="text" id="inputAddress" name="address" class="form-control" placeholder="Full address" autofocus>
    @if ($errors->has('address'))
    <span class="error">{{ $errors->first('address') }}</span>
    @endif       

  </div>

  <div class="form-group">
    <label for="inputPhoneno">Mobile</label>
    <input type="text" id="inputPhoneno" name="phoneno" class="form-control" placeholder="Mobile No" autofocus>

    @if ($errors->has('phoneno'))
    <span class="error">{{ $errors->first('phoneno') }}</span>
    @endif       

  </div>

  <div class="form-label-group">
    <label for="inputName">Address</label>

     <input type="text" id="inputName" name="name" class="form-control" placeholder="Address" autofocus>
     @if ($errors->has('name'))
     <span class="error">{{ $errors->first('name') }}</span>
     @endif    

   </div> 

   

   <button class="btn btn-lg btn-primary btn-block btn-login text-uppercase font-weight-bold mb-2" type="submit">Select Table</button>
   
 </form>
</div>
 @endsection