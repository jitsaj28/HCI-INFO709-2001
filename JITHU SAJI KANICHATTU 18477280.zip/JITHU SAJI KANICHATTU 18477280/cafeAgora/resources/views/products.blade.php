@extends('layout')

@section('content')
<div class="row">
    <div class="col-sm-4">
      <div class="panel panel-primary">
        <div class="panel-heading"></div>
        <div class="panel-body"><img src="https://placehold.it/150x80?text=IMAGE" class="img-responsive" style="width:100%" alt="Image"></div>
        <div class="panel-footer"></div>
      </div>
    </div>
  </div>
  @endsection